from changanya import nilsimsa
from scapy.all import *
import time 

def create_nilsimsa_hash(data): 
    hash = nilsimsa.Nilsimsa(data)
    return hash

def compare_hashes(hash_a, hash_b):
    distance_measure = nilsimsa.Nilsimsa.similarity(hash_a, hash_b)
    return distance_measure

def read_pcap(file_path):
    a = rdpcap(file_path)
    return a

def read_sessions(pcap_data):
    sessions = pcap_data.sessions()
    return sessions

'''
copied from Stackoverflow
'''
def time_convert(sec):
    mins = sec // 60
    sec = sec % 60
    hours = mins // 60
    mins = mins % 60
    converted_time_as_string = "{0}:{1}:{2}".format(int(hours),int(mins),sec)
    return converted_time_as_string


def stopwatch(func):
    start_time = time.time()
    function_result = func
    end_time = time.time()
    time_elapsed = end_time - start_time
    time_as_string = time_convert(time_elapsed)
    output = "This operation took {}".format(time_as_string)
    print(output)
    return function_result


if __name__ == '__main__':
    
    hash_a = create_nilsimsa_hash("test")
    hash_b = create_nilsimsa_hash("another test")

    compare_hashes(hash_a, hash_b)
    compare_hashes(hash_a, hash_a)

    pcap_data = read_pcap("IOT_TRACES/Setup-C-15-STAD-LinkSiren.pcap")

    sessions = read_sessions(pcap_data)

    raw_trace_data_string = ""

    for session in sessions:
        for packet in sessions[session]:
            raw_trace_data_string+=str(packet)


    print("="*15 + " HASHING " + "="*15)
    nilsimsaHash = stopwatch(create_nilsimsa_hash(raw_trace_data_string))
    print("-"*12 + " COMPARISON " + "-"*12)
    hashComparison = stopwatch(compare_hashes(nilsimsaHash,nilsimsaHash))


